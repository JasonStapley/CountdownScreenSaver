using System;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;
using System.Timers;

namespace ScreenSaver
{
	public class CountdownScreenSaverForm : System.Windows.Forms.Form
	{
		private System.ComponentModel.IContainer components;
		private Point MouseXY;
		private int ScreenNumber;
        public bool exitFlag;
        private Label labelText;
        static System.Windows.Forms.Timer myTimer = new System.Windows.Forms.Timer();
        private string message;
        private DateTime EndDate;


        public CountdownScreenSaverForm(int scrn)
		{
			InitializeComponent();
			ScreenNumber = scrn;
            
        }

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

        // This is the method to run when the timer is raised.
        private void TimerEventProcessor(Object myObject,
                                                EventArgs myEventArgs)
        {
            this.Render();
        }


        private void Render()
        {
            Random rnd = new Random();
            int labelx = rnd.Next(1, Bounds.Width);
            int labely = rnd.Next(1, Bounds.Height);
          
            DateTime StartDate = DateTime.Today;
            

            double daysUntil = EndDate.Subtract(DateTime.Today).TotalDays;

            string labelmessage = String.Format("There are {0} day{1} until {2}", (int)daysUntil, this.Plural(daysUntil), this.message);
            labelText.Text = labelmessage;

            // If the lable off the screen move it to a viable location
            if (labelx > Bounds.Width - labelText.Width)
            {
                labelx = Bounds.Width - labelText.Width;
            }            
            labelText.Location = new Point(labelx, labely);
            labelText.ForeColor = Color.FromArgb(rnd.Next(1, 255), rnd.Next(1, 255), rnd.Next(1, 255));
        }

        private string Plural(double number)
        {
            if(number>0)
            {
                return "s";
            }
            return "";
        }

        private void ScreenSaverForm_Load(object sender, System.EventArgs e)
		{
            this.Bounds = Screen.AllScreens[ScreenNumber].Bounds;
			Cursor.Hide();
			TopMost = true;

            myTimer.Tick += new EventHandler(this.TimerEventProcessor);

            this.EndDate = Configuration.CountdownDate;
            this.message = Configuration.CountdownText;

            // Set the time as soon as the screen saver is opened
            this.Render();

            // Sets the timer interval to what set in the registry.
            myTimer.Interval = Configuration.CountdownInterval;
            myTimer.Start();

            
        }

		private void OnMouseEvent(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (!MouseXY.IsEmpty)
			{
				if (MouseXY != new Point(e.X, e.Y))
                {
                    myTimer.Stop();
                    exitFlag = true;
                    Close();
                }
                if (e.Clicks > 0)
                {
                    myTimer.Stop();
                    exitFlag = true;
                    Close();
                }
			}
			MouseXY = new Point(e.X, e.Y);
		}
		
		private void ScreenSaverForm_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
            myTimer.Stop();
            exitFlag = true;
            Close();
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.labelText = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelText
            // 
            this.labelText.AutoSize = true;
            this.labelText.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelText.ForeColor = System.Drawing.SystemColors.Info;
            this.labelText.Location = new System.Drawing.Point(52, 130);
            this.labelText.Name = "labelText";
            this.labelText.Size = new System.Drawing.Size(33, 16);
            this.labelText.TabIndex = 0;
            this.labelText.Text = "Test";
            // 
            // CountdownScreenSaverForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.labelText);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CountdownScreenSaverForm";
            this.Text = "ScreenSaver";
            this.Load += new System.EventHandler(this.ScreenSaverForm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ScreenSaverForm_KeyDown);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.OnMouseEvent);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.OnMouseEvent);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion
	}
}
