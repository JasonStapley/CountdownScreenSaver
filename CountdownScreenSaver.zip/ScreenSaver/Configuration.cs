﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Win32;

namespace ScreenSaver
{
    class Configuration
    {
        // The name of the key must include a valid root.
        const string userRoot = "HKEY_CURRENT_USER";        
        const string Subkey = "CountdownScreenSaver";
        const string keyName = userRoot + "\\" + Subkey;


        static public DateTime CountdownDate
        {
            get
            {
                Registry.CurrentUser.CreateSubKey(Subkey);
                return DateTime.Parse(Registry.GetValue(keyName, "CountdownDate", "2016-11-25").ToString());
            }
            set
            {
                Registry.CurrentUser.CreateSubKey(Subkey);
                Registry.SetValue(keyName, "CountdownDate", value, RegistryValueKind.String);
            }
        }

        static public string CountdownText
        {
            get
            {
                Registry.CurrentUser.CreateSubKey(Subkey);
                return Registry.GetValue(keyName, "CountdownText", "Enter text here").ToString();
            }
            set
            {
                Registry.CurrentUser.CreateSubKey(Subkey);
                Registry.SetValue(keyName, "CountdownText", value, RegistryValueKind.String);
            }
        }

        static public string Fontname
        {
            get
            {
                Registry.CurrentUser.CreateSubKey(Subkey);
                return Registry.GetValue(keyName, "Fontname", "Microsoft Sans Serif").ToString();
            }
            set
            {
                Registry.CurrentUser.CreateSubKey(Subkey);
                Registry.SetValue(keyName, "Fontname", value, RegistryValueKind.String);
            }
        }

        static public string Fontsize
        {
            get
            {
                Registry.CurrentUser.CreateSubKey(Subkey);
                return Registry.GetValue(keyName, "Fontsize", "8.25").ToString();
            }
            set
            {
                Registry.CurrentUser.CreateSubKey(Subkey);
                Registry.SetValue(keyName, "Fontsize", value, RegistryValueKind.String);
            }
        }

        
        static public decimal CountdownInterval
        {
            get
            {
                Registry.CurrentUser.CreateSubKey(Subkey);
                return Int32.Parse(Registry.GetValue(keyName, "CountdownInterval", 5).ToString());
            }
            set
            {
                Registry.CurrentUser.CreateSubKey(Subkey);
                Registry.SetValue(keyName, "CountdownInterval", value, RegistryValueKind.DWord);
            }
        }
    }
}
